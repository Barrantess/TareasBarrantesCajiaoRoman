puts "What's your name"
my_name = gets.strip

puts "Hello, #{my_name}!"
