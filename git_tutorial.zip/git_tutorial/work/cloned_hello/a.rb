puts "Hello, #{ARGV.first}!"
